"""Tests for regression models."""
